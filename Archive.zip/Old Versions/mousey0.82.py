# Mousey (a Nibbles clone)
# By Caroline Larsen
# http://inventwithpython.com/pygame
# Released under a "Simplified BSD" license

import random, pygame, math, time, sys
from pygame.locals import *

TITLE = 'Mousie! v0.82'

TITLE_FPS = 15
GAME_FPS = 15
WINDOWWIDTH = 800
WINDOWHEIGHT = 480
CELLSIZE = 20
assert WINDOWWIDTH % CELLSIZE == 0, "Window width must be a multiple of cell size."
assert WINDOWHEIGHT % CELLSIZE == 0, "Window height must be a multiple of cell size."
CELLWIDTH = int(WINDOWWIDTH / CELLSIZE)
CELLHEIGHT = int(WINDOWHEIGHT / CELLSIZE)

#             R    G    B
WHITE     = (255, 255, 255)
BLACK     = (  0,   0,   0)
RED       = (255,   0,   0)
GREEN     = (  0, 255,   0)
DARKGREEN = (  0, 155,   0)
DARKGRAY  = ( 40,  40,  40)
BGCOLOR   = BLACK
DARKYELLOW= (  190,   190,   0)
GRAY      = (  95,   95,   95)
YELLOW    = (  255,   255,   0)
BLUE     = (  0,   0,   175)
UP = 'up'
DOWN = 'down'
LEFT = 'left'
RIGHT = 'right'
STOPPED = 'stopped'

def main():
    global FPSCLOCK, DISPLAYSURF, BASICFONT

    pygame.init()    
    FPSCLOCK = pygame.time.Clock()
    DISPLAYSURF = pygame.display.set_mode((WINDOWWIDTH, WINDOWHEIGHT))
    BASICFONT = pygame.font.Font('freesansbold.ttf', 18)
    pygame.display.set_caption(TITLE)

    showStartScreen()
 
    while True:
        runGame()
        showGameOverScreen()


def runGame():
    # Initialize everything.
    score = 0
    wonSound = pygame.mixer.Sound('Meow.wav')
    timerSound = pygame.mixer.Sound('Continuous.ogg')

    # Set a random start point for the mouse somewhere near the center.
    startx = random.randint(5, CELLWIDTH - 6)
    starty = random.randint(5, CELLHEIGHT - 6)
    mouseCoord = {'x': startx,'y': starty}
    keyState = {'left' : False, 'right' : False, 'up' : False, 'down' : False}

    # Set the cheese in a random place.
    cheese = getRandomLocation()

    currentTime = time.time()
    soundTimer = currentTime
    gameTimer = currentTime
    soundInterval = 0.6
    timerSound.play(-1)

    maxDistance = math.sqrt ( CELLWIDTH ** 2 + CELLHEIGHT ** 2 )

    while True: # The main game loop

        # Play a sound every interval
        currentTime = time.time()
        
        if time.time() - soundTimer >= soundInterval:
            soundTimer = time.time()
            #print str(currentTime - soundTimer) + "seconds"
            mixerClock = pygame.time.Clock()
            #timerSound.play()
            #while pygame.mixer.get_busy():
            #   mixerClock.tick(30)
        

        if time.time() - gameTimer > 1.0 / 15.0:
            gameTimer = time.time()
            # Process all user input events.
            for event in pygame.event.get():           
                if event.type == KEYDOWN or event.type == KEYUP:
                    keyDown = (event.type == KEYDOWN)
                    if (event.key == K_LEFT or event.key == K_a):
                        keyState['left'] = keyDown              
                    elif (event.key == K_RIGHT or event.key == K_d):
                        keyState['right'] = keyDown
                    elif (event.key == K_UP or event.key == K_w):
                        keyState['up'] = keyDown
                    elif (event.key == K_DOWN or event.key == K_s):
                        keyState['down'] = keyDown
                    elif (event.key == K_u):
                        soundInterval -= 0.01
                    elif (event.key == K_i):
                        soundInterval += 0.01
                    elif (event.key == K_ESCAPE):
                        terminate()
                elif event.type == QUIT:
                    terminate()
          
            # If the mouse has eaten a cheese, then increment the score and move the cheese.
            if mouseCoord['x'] == cheese['x'] and mouseCoord['y'] == cheese['y']:
                wonSound.play()
                score = score + 1
                cheese = getRandomLocation()
               
            # Move the mouse by updating its position based on the key state.
            if keyState['left'] and mouseCoord [ 'x' ] > 0:
                mouseCoord['x'] = mouseCoord['x'] - 1
            if keyState['right'] and mouseCoord [ 'x' ] < CELLWIDTH - 1:
                mouseCoord['x'] = mouseCoord['x'] + 1
            if keyState['up'] and mouseCoord [ 'y' ] > 0:
                mouseCoord['y'] = mouseCoord['y'] - 1
            if keyState['down'] and mouseCoord[ 'y' ] < CELLHEIGHT - 1:
                mouseCoord['y'] = mouseCoord['y'] + 1
    
            # Find the distance between the mouse and the cheese.
            distance = math.sqrt ((mouseCoord['x'] - cheese['x']) ** 2 + (mouseCoord['y'] - cheese['y']) ** 2)

            volumeLevel = 1.0 - distance / maxDistance
            timerSound.set_volume (volumeLevel)

            # Draw everything
            DISPLAYSURF.fill(BGCOLOR)
            drawGrid()
            drawMouse(mouseCoord)
            drawCheese(cheese)
            drawScore(score, distance)
            pygame.display.update()

            # Don't run too fast. Pause here briefly to maintain 15 frames per second.
            # FPSCLOCK.tick(GAME_FPS)

def drawPressKeyMsg():
    pressKeySurf = BASICFONT.render('Press a key to play.', True, DARKGRAY)
    pressKeyRect = pressKeySurf.get_rect()
    pressKeyRect.topleft = (WINDOWWIDTH - 200, WINDOWHEIGHT - 30)
    DISPLAYSURF.blit(pressKeySurf, pressKeyRect)


def checkForKeyPress():
    if len(pygame.event.get(QUIT)) > 0:
        terminate()

    keyUpEvents = pygame.event.get(KEYUP)
    if len(keyUpEvents) == 0:
        return None
    if keyUpEvents[0].key == K_ESCAPE:
        terminate()
    return keyUpEvents[0].key


def showStartScreen():
    titleFont = pygame.font.Font('freesansbold.ttf', 100)
    titleSurf1 = titleFont.render(TITLE, True, GRAY, BLUE)
    titleSurf2 = titleFont.render(TITLE, True, DARKYELLOW)

    degrees1 = 0
    degrees2 = 0
    while True:
        DISPLAYSURF.fill(BGCOLOR)
        rotatedSurf1 = pygame.transform.rotate(titleSurf1, degrees1)
        rotatedRect1 = rotatedSurf1.get_rect()
        rotatedRect1.center = (WINDOWWIDTH / 2, WINDOWHEIGHT / 2)
        DISPLAYSURF.blit(rotatedSurf1, rotatedRect1)

        rotatedSurf2 = pygame.transform.rotate(titleSurf2, degrees2)
        rotatedRect2 = rotatedSurf2.get_rect()
        rotatedRect2.center = (WINDOWWIDTH / 2, WINDOWHEIGHT / 2)
        DISPLAYSURF.blit(rotatedSurf2, rotatedRect2)

        drawPressKeyMsg()

        if checkForKeyPress():
            pygame.event.get() # clear event queue
            return
        pygame.display.update()
        FPSCLOCK.tick(TITLE_FPS)
        degrees1 += 3 # rotate by 3 degrees each frame
        degrees2 += 7 # rotate by 7 degrees each frame


def terminate():
    pygame.quit()
    sys.exit()


def getRandomLocation():
    return {'x': random.randint(0, CELLWIDTH - 1), 'y': random.randint(0, CELLHEIGHT - 1)}


def showGameOverScreen():
    gameOverFont = pygame.font.Font('freesansbold.ttf', 150)
    gameSurf = gameOverFont.render('Game', True, WHITE)
    overSurf = gameOverFont.render('Over', True, WHITE)
    gameRect = gameSurf.get_rect()
    overRect = overSurf.get_rect()
    gameRect.midtop = (WINDOWWIDTH / 2, 10)
    overRect.midtop = (WINDOWWIDTH / 2, gameRect.height + 10 + 25)

    DISPLAYSURF.blit(gameSurf, gameRect)
    DISPLAYSURF.blit(overSurf, overRect)
    drawPressKeyMsg()
    pygame.display.update()
    pygame.time.wait(500)
    checkForKeyPress() # clear out any key presses in the event queue

    while True:
        if checkForKeyPress():
            pygame.event.get() # clear event queue
            return

def drawScore(score, distance):
    scoreSurf = BASICFONT.render('Score: %s' % (score), True, WHITE)
    scoreRect = scoreSurf.get_rect()
    scoreRect.topleft = (WINDOWWIDTH - 180, 10)
    DISPLAYSURF.blit(scoreSurf, scoreRect)
    
    distSurf = BASICFONT.render('Distance: %s' % (distance), True, WHITE)
    distRect = distSurf.get_rect()
    distRect.topleft = (WINDOWWIDTH - 180, 30)
    DISPLAYSURF.blit(distSurf, distRect)

def drawMouse(mouseCoord):
    x = mouseCoord['x'] * CELLSIZE
    y = mouseCoord['y'] * CELLSIZE
    mouseSegmentRect = pygame.Rect(x, y, CELLSIZE, CELLSIZE)
    pygame.draw.rect(DISPLAYSURF, WHITE, mouseSegmentRect)
    mouseInnerSegmentRect = pygame.Rect(x + 4, y + 4, CELLSIZE - 8, CELLSIZE - 8)
    pygame.draw.rect(DISPLAYSURF, GRAY, mouseInnerSegmentRect)


def drawCheese(coord):
    x = coord['x'] * CELLSIZE
    y = coord['y'] * CELLSIZE
    cheeseRect = pygame.Rect(x, y, CELLSIZE, CELLSIZE)
    pygame.draw.rect(DISPLAYSURF, YELLOW, cheeseRect)


def drawGrid():
    for x in range(0, WINDOWWIDTH, CELLSIZE): # draw vertical lines
        pygame.draw.line(DISPLAYSURF, DARKGRAY, (x, 0), (x, WINDOWHEIGHT))
    for y in range(0, WINDOWHEIGHT, CELLSIZE): # draw horizontal lines
        pygame.draw.line(DISPLAYSURF, DARKGRAY, (0, y), (WINDOWWIDTH, y))


# sound stuff
FREQ = 44100   # same as audio CD
BITSIZE = -16  # unsigned 16 bit
CHANNELS = 2   # 1 == mono, 2 == stereo
BUFFER = 1024  # audio buffer size in no. of samples
FRAMERATE = 30 # how often to check if playback has finished

def initSound():
    # initialize pygame.mixer module
    # if these setting do not work with your audio system
    # change the global constants accordingly
    try:
        pygame.mixer.init(FREQ, BITSIZE, CHANNELS, BUFFER)
    except pygame.error, exc:
        print >>sys.stderr, "Could not initialize sound system: %s" % exc
        return 1
    
def playSound(soundfile):
    """Play sound through default mixer channel in blocking manner.   
    This will load the whole sound into memory before playback
    """

    sound = pygame.mixer.Sound(soundfile)
    clock = pygame.time.Clock()
    sound.play()
    while pygame.mixer.get_busy():
        clock.tick(FRAMERATE)

if __name__ == '__main__':
    main()
